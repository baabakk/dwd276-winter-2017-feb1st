import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  searchItems = [
    {
      title:"This a good search result",
      url:"http://theUrl",
      description:"Description of this search result comes here!"
    },
    {
      title:"This a good search result",
      url:"http://theUrl",
      description:"Description of this search result comes here!"
    }
  ];
}
